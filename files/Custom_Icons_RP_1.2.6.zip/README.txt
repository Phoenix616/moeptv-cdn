You can feel free to modify and distribute this resource pack as you wish, or include parts of it in your own resource packs, but you must include the copyright notice found in assets/minecraft/textures/font. The copyright notice applies only to the ten fontsheets included in that folder.

Feel free to delete this README.txt, and thank you for downloading!

~WolfieMario